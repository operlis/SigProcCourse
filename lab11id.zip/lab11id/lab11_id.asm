; ---------------------------------------------------------
; lab11_id.asm
; חישוב סכום ספרות של מספר תעודת זהות מתוך קובץ ID.TXT
; ---------------------------------------------------------

.MODEL small
.STACK 100h

.DATA
filename db 'ID.TXT',0
handle   dw ?
char_in  db ?        ; תו שנקרא מהקובץ (לא רגיסטר שמור!)
sum      dw 0

msg_id   db 'ID: $'
msg_sum  db 0Dh,0Ah,'Sum of digits (base 10): $'

.CODE
start:
    mov ax, @data
    mov ds, ax

; ---------------------------------------------------------
; פתיחת הקובץ לקריאה
; ---------------------------------------------------------
    mov ah, 3Dh          ; DOS open file
    mov al, 0            ; read only
    lea dx, filename
    int 21h
    jc exit_program
    mov handle, ax

; ---------------------------------------------------------
; הדפסת "ID: "
; ---------------------------------------------------------
    lea dx, msg_id
    mov ah, 09h
    int 21h

; ---------------------------------------------------------
; קריאה תו-תו מהקובץ
; ---------------------------------------------------------
read_loop:
    mov ah, 3Fh          ; DOS read
    mov bx, handle
    lea dx, char_in
    mov cx, 1
    int 21h
    cmp ax, 0            ; EOF?
    je close_file

    mov dl, char_in      ; הדפסת הספרה
    mov ah, 02h
    int 21h

    sub dl, '0'          ; ASCII -> מספר
    mov al, dl
    xor ah, ah
    add sum, ax

    jmp read_loop

; ---------------------------------------------------------
; סגירת הקובץ
; ---------------------------------------------------------
close_file:
    mov ah, 3Eh
    mov bx, handle
    int 21h

; ---------------------------------------------------------
; הדפסת סכום הספרות
; ---------------------------------------------------------
    lea dx, msg_sum
    mov ah, 09h
    int 21h

    mov ax, sum
    call print_number

exit_program:
    mov ah, 4Ch
    int 21h

; ---------------------------------------------------------
; פרוצדורה להדפסת מספר עשרוני (בסיס 10)
; ---------------------------------------------------------
print_number PROC
    mov bx, 10
    xor cx, cx

convert_loop:
    xor dx, dx
    div bx
    push dx
    inc cx
    cmp ax, 0
    jne convert_loop

print_loop:
    pop dx
    add dl, '0'
    mov ah, 02h
    int 21h
    loop print_loop
    ret
print_number ENDP

END start
